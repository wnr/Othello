package org.mockito.release.notes;

class GitCommit {
    String email
    String author
    String message
}