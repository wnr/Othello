package org.mockito.internal.rules;

/**
 * Created by jerzy on 2014-09-19.
 */
public class JunitRuleImpl {
}
